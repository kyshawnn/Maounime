import Link from 'next/link';
import { Search, Film } from 'lucide-react';

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800 bg-[#0a0a0a]/95 backdrop-blur">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-7 h-7 rounded bg-white flex items-center justify-center text-black font-black text-sm tracking-tighter">
            M
          </div>
          <span className="font-bold text-lg tracking-tight text-white group-hover:text-neutral-300 transition">
            MAOUNIME
          </span>
        </Link>

        <div className="flex items-center gap-3">
          <Link
            href="/search"
            className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-neutral-800 bg-neutral-900 text-xs font-medium text-neutral-300 hover:text-white hover:border-neutral-700 transition"
          >
            <Search className="w-3.5 h-3.5 text-neutral-400" />
            <span>Pencarian</span>
          </Link>
        </div>
      </div>
    </header>
  );
}
