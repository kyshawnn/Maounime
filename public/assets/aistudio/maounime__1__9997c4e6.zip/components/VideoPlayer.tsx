'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Settings,
  Maximize,
  Minimize,
  Check,
  ChevronRight,
  Download,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { VideoMirror, DownloadLink } from '@/lib/sokuja';

interface VideoPlayerProps {
  title: string;
  mirrors: VideoMirror[];
  downloads: DownloadLink[];
  animeTitle: string;
}

function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '00:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);

  if (hrs > 0) {
    return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

export default function VideoPlayer({ mirrors, downloads }: VideoPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);
  const hideControlsTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [selectedMirrorIndex, setSelectedMirrorIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [bufferedEnd, setBufferedEnd] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isScrubbing, setIsScrubbing] = useState(false);
  const [hoverPosition, setHoverPosition] = useState<number | null>(null);
  const [hoverTime, setHoverTime] = useState<string>('00:00');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [settingsView, setSettingsView] = useState<'main' | 'quality' | 'server' | 'speed'>('main');
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [playerError, setPlayerError] = useState(false);
  const [useProxy, setUseProxy] = useState(false);
  const [centerAnimation, setCenterAnimation] = useState<'play' | 'pause' | 'fwd' | 'rwd' | null>(null);

  const activeMirror = mirrors[selectedMirrorIndex] || null;

  // Stream URL
  const currentStreamUrl = activeMirror
    ? useProxy
      ? `/api/stream?url=${encodeURIComponent(activeMirror.streamUrl)}`
      : activeMirror.streamUrl
    : '';

  // Get available resolutions
  const availableQualities = Array.from(new Set(mirrors.map((m) => m.quality)));
  const currentQuality = activeMirror?.quality || '720p';

  // Auto-hide controls
  const resetHideControlsTimer = useCallback(() => {
    setShowControls(true);
    if (hideControlsTimerRef.current) {
      clearTimeout(hideControlsTimerRef.current);
    }
    if (isPlaying && !isSettingsOpen) {
      hideControlsTimerRef.current = setTimeout(() => {
        setShowControls(false);
      }, 2500);
    }
  }, [isPlaying, isSettingsOpen]);

  useEffect(() => {
    if (hideControlsTimerRef.current) {
      clearTimeout(hideControlsTimerRef.current);
    }
    if (isPlaying && !isSettingsOpen) {
      hideControlsTimerRef.current = setTimeout(() => {
        setShowControls(false);
      }, 2500);
    }
    return () => {
      if (hideControlsTimerRef.current) {
        clearTimeout(hideControlsTimerRef.current);
      }
    };
  }, [isPlaying, isSettingsOpen]);

  // Video source reload on switch
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.load();
    }
  }, [selectedMirrorIndex, useProxy]);

  // Center indicator flash
  const flashCenter = (type: 'play' | 'pause' | 'fwd' | 'rwd') => {
    setCenterAnimation(type);
    setTimeout(() => setCenterAnimation(null), 500);
  };

  // Play / Pause toggle
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused || videoRef.current.ended) {
      videoRef.current.play().then(() => {
        setIsPlaying(true);
        flashCenter('play');
      }).catch(() => {});
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
      flashCenter('pause');
    }
  };

  // Seek +/- 10s
  const seekRelative = (delta: number) => {
    if (!videoRef.current) return;
    const target = Math.min(Math.max(0, videoRef.current.currentTime + delta), duration || 99999);
    videoRef.current.currentTime = target;
    setCurrentTime(target);
    flashCenter(delta > 0 ? 'fwd' : 'rwd');
    resetHideControlsTimer();
  };

  // Volume change
  const handleVolumeChange = (newVol: number) => {
    if (!videoRef.current) return;
    const clamped = Math.max(0, Math.min(1, newVol));
    videoRef.current.volume = clamped;
    setVolume(clamped);
    if (clamped === 0) {
      setIsMuted(true);
      videoRef.current.muted = true;
    } else if (isMuted) {
      setIsMuted(false);
      videoRef.current.muted = false;
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      setIsMuted(false);
      if (volume === 0) {
        setVolume(0.5);
        videoRef.current.volume = 0.5;
      }
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  // Fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  // Time & Buffer updates
  const handleTimeUpdate = () => {
    if (!videoRef.current || isScrubbing) return;
    setCurrentTime(videoRef.current.currentTime);

    // Buffer percentage
    const b = videoRef.current.buffered;
    if (b.length > 0 && videoRef.current.duration > 0) {
      const bufferedSec = b.end(b.length - 1);
      setBufferedEnd((bufferedSec / videoRef.current.duration) * 100);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  // Scrubbing & Red Progress Bar Handling
  const calculateProgressFromEvent = (e: React.MouseEvent<HTMLDivElement> | MouseEvent): number => {
    if (!progressBarRef.current) return 0;
    const rect = progressBarRef.current.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    return Math.max(0, Math.min(1, pos));
  };

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!videoRef.current || duration <= 0) return;
    const pos = calculateProgressFromEvent(e);
    const target = pos * duration;
    videoRef.current.currentTime = target;
    setCurrentTime(target);
    resetHideControlsTimer();
  };

  const handleProgressBarMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current || duration <= 0) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    const clamped = Math.max(0, Math.min(1, pos));
    setHoverPosition(clamped * 100);
    setHoverTime(formatTime(clamped * duration));
  };

  const handleProgressBarMouseLeave = () => {
    setHoverPosition(null);
  };

  // Change Quality inside Settings
  const selectQuality = (q: string) => {
    const idx = mirrors.findIndex((m) => m.quality === q);
    if (idx !== -1) {
      setSelectedMirrorIndex(idx);
    }
    setIsSettingsOpen(false);
    setSettingsView('main');
  };

  // Change Server inside Settings
  const selectServer = (idx: number) => {
    if (idx >= 0 && idx < mirrors.length) {
      setSelectedMirrorIndex(idx);
    }
    setIsSettingsOpen(false);
    setSettingsView('main');
  };

  // Change Speed
  const selectSpeed = (spd: number) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = spd;
      setPlaybackSpeed(spd);
    }
    setIsSettingsOpen(false);
    setSettingsView('main');
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) return;

      if (e.key === ' ' || e.key === 'k') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowLeft' || e.key === 'j') {
        e.preventDefault();
        seekRelative(-10);
      } else if (e.key === 'ArrowRight' || e.key === 'l') {
        e.preventDefault();
        seekRelative(10);
      } else if (e.key === 'f') {
        e.preventDefault();
        toggleFullscreen();
      } else if (e.key === 'm') {
        e.preventDefault();
        toggleMute();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        handleVolumeChange(volume + 0.1);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleVolumeChange(volume - 0.1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="flex flex-col gap-4">
      {/* YouTube Style Player Container */}
      <div
        ref={containerRef}
        onMouseMove={resetHideControlsTimer}
        onMouseEnter={() => setShowControls(true)}
        className="relative w-full aspect-video bg-black rounded-xl overflow-hidden border border-neutral-800 shadow-2xl select-none group"
      >
        {/* Real Video Element (controls disabled for YouTube-style UI) */}
        {currentStreamUrl && !playerError ? (
          <video
            ref={videoRef}
            src={currentStreamUrl}
            controls={false}
            playsInline
            preload="metadata"
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => setIsPlaying(false)}
            onClick={togglePlay}
            onError={() => {
              if (!useProxy) {
                setUseProxy(true);
              } else {
                setPlayerError(true);
              }
            }}
            className="w-full h-full object-contain bg-black cursor-pointer"
          />
        ) : (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-[#111111]">
            <AlertCircle className="w-8 h-8 text-neutral-500 mb-2" />
            <p className="text-sm font-semibold text-neutral-200">
              {mirrors.length === 0
                ? 'Server video untuk episode ini sedang disiapkan.'
                : 'Kendala memuat server video.'}
            </p>
            <p className="text-xs text-neutral-400 mt-1 max-w-md">
              Pilih resolusi atau jalur cadangan melalui menu pengaturan player di bawah.
            </p>
            {mirrors.length > 0 && (
              <button
                onClick={() => {
                  setPlayerError(false);
                  setUseProxy(!useProxy);
                }}
                className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-white transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Ganti Mode ({useProxy ? 'Direct' : 'Proxy'})</span>
              </button>
            )}
          </div>
        )}

        {/* Center Click Action Flash Animation */}
        {centerAnimation && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
            <div className="w-16 h-16 rounded-full bg-black/60 flex items-center justify-center text-white scale-125 transition-transform duration-300">
              {centerAnimation === 'play' && <Play className="w-8 h-8 fill-white ml-1" />}
              {centerAnimation === 'pause' && <Pause className="w-8 h-8 fill-white" />}
              {centerAnimation === 'fwd' && (
                <div className="flex flex-col items-center">
                  <RotateCw className="w-6 h-6" />
                  <span className="text-[10px] font-bold mt-0.5">+10s</span>
                </div>
              )}
              {centerAnimation === 'rwd' && (
                <div className="flex flex-col items-center">
                  <RotateCcw className="w-6 h-6" />
                  <span className="text-[10px] font-bold mt-0.5">-10s</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* YouTube Settings Popover Menu */}
        {isSettingsOpen && (
          <div className="absolute bottom-14 right-4 z-40 w-64 rounded-xl bg-neutral-900 border border-neutral-700 text-white shadow-2xl p-1.5 text-xs animate-in fade-in zoom-in-95 duration-150">
            {/* Main Menu */}
            {settingsView === 'main' && (
              <div className="space-y-0.5">
                <button
                  onClick={() => setSettingsView('quality')}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-neutral-800 transition"
                >
                  <span className="text-neutral-300">Kualitas Resolusi</span>
                  <div className="flex items-center gap-1 text-neutral-400">
                    <span className="font-semibold text-white">{currentQuality}</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </button>

                <button
                  onClick={() => setSettingsView('server')}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-neutral-800 transition"
                >
                  <span className="text-neutral-300">Pilihan Server</span>
                  <div className="flex items-center gap-1 text-neutral-400">
                    <span className="font-semibold text-white">{activeMirror?.serverName || 'Server Utama'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </button>

                <button
                  onClick={() => setSettingsView('speed')}
                  className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-neutral-800 transition"
                >
                  <span className="text-neutral-300">Kecepatan Putar</span>
                  <div className="flex items-center gap-1 text-neutral-400">
                    <span className="font-semibold text-white">{playbackSpeed === 1 ? 'Normal' : `${playbackSpeed}x`}</span>
                    <ChevronRight className="w-4 h-4" />
                  </div>
                </button>
              </div>
            )}

            {/* Quality Submenu */}
            {settingsView === 'quality' && (
              <div>
                <button
                  onClick={() => setSettingsView('main')}
                  className="w-full flex items-center gap-2 px-3 py-2 border-b border-neutral-800 text-neutral-400 hover:text-white mb-1"
                >
                  <ChevronRight className="w-4 h-4 rotate-180" />
                  <span className="font-semibold">Kualitas Resolusi</span>
                </button>
                {availableQualities.map((q) => (
                  <button
                    key={q}
                    onClick={() => selectQuality(q)}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-neutral-800 transition text-left"
                  >
                    <span>{q}</span>
                    {q === currentQuality && <Check className="w-4 h-4 text-white" />}
                  </button>
                ))}
              </div>
            )}

            {/* Server Submenu */}
            {settingsView === 'server' && (
              <div>
                <button
                  onClick={() => setSettingsView('main')}
                  className="w-full flex items-center gap-2 px-3 py-2 border-b border-neutral-800 text-neutral-400 hover:text-white mb-1"
                >
                  <ChevronRight className="w-4 h-4 rotate-180" />
                  <span className="font-semibold">Pilihan Server</span>
                </button>
                {mirrors.map((m, idx) => (
                  <button
                    key={`${m.quality}-${idx}`}
                    onClick={() => selectServer(idx)}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-neutral-800 transition text-left"
                  >
                    <span>{m.serverName} ({m.quality})</span>
                    {idx === selectedMirrorIndex && <Check className="w-4 h-4 text-white" />}
                  </button>
                ))}
              </div>
            )}

            {/* Speed Submenu */}
            {settingsView === 'speed' && (
              <div>
                <button
                  onClick={() => setSettingsView('main')}
                  className="w-full flex items-center gap-2 px-3 py-2 border-b border-neutral-800 text-neutral-400 hover:text-white mb-1"
                >
                  <ChevronRight className="w-4 h-4 rotate-180" />
                  <span className="font-semibold">Kecepatan Putar</span>
                </button>
                {[0.5, 0.75, 1, 1.25, 1.5, 2].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => selectSpeed(spd)}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-lg hover:bg-neutral-800 transition text-left"
                  >
                    <span>{spd === 1 ? 'Normal' : `${spd}x`}</span>
                    {spd === playbackSpeed && <Check className="w-4 h-4 text-white" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* YouTube Controls Overlay (Bottom) */}
        <div
          className={`absolute inset-x-0 bottom-0 z-30 transition-opacity duration-300 bg-black/85 pt-8 pb-2 px-4 ${
            showControls || !isPlaying || isSettingsOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          }`}
        >
          {/* YouTube Red Progress Bar */}
          <div
            ref={progressBarRef}
            onClick={handleProgressBarClick}
            onMouseMove={handleProgressBarMouseMove}
            onMouseLeave={handleProgressBarMouseLeave}
            className="relative w-full h-3 flex items-center cursor-pointer group/bar mb-2.5"
          >
            {/* Hover Tooltip Timestamp */}
            {hoverPosition !== null && (
              <div
                style={{ left: `${hoverPosition}%` }}
                className="absolute -top-7 -translate-x-1/2 px-2 py-0.5 rounded bg-neutral-900 border border-neutral-700 text-[11px] font-mono font-semibold text-white pointer-events-none shadow"
              >
                {hoverTime}
              </div>
            )}

            {/* Background Rail */}
            <div className="w-full h-1 group-hover/bar:h-1.5 transition-all bg-white/20 rounded-full overflow-hidden relative">
              {/* Buffer Bar */}
              <div
                style={{ width: `${bufferedEnd}%` }}
                className="absolute inset-y-0 left-0 bg-white/30"
              />
              {/* YouTube Red Progress Bar */}
              <div
                style={{ width: `${progressPercent}%` }}
                className="absolute inset-y-0 left-0 bg-[#ff0000]"
              />
            </div>

            {/* Red Scrubber Circle Handle */}
            <div
              style={{ left: `${progressPercent}%` }}
              className="absolute -translate-x-1/2 w-3.5 h-3.5 rounded-full bg-[#ff0000] scale-0 group-hover/bar:scale-100 transition-transform shadow"
            />
          </div>

          {/* YouTube Control Buttons Bar */}
          <div className="flex items-center justify-between text-white">
            {/* Left Controls: Play, -10s, +10s, Volume, Time */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Play / Pause Toggle */}
              <button
                onClick={togglePlay}
                className="p-1.5 rounded-full hover:bg-white/10 transition"
                title={isPlaying ? 'Jeda (Space)' : 'Putar (Space)'}
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white ml-0.5" />}
              </button>

              {/* Backward 10s */}
              <button
                onClick={() => seekRelative(-10)}
                className="p-1.5 rounded-full hover:bg-white/10 transition text-neutral-300 hover:text-white"
                title="Mundur 10 Detik (J)"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Forward 10s */}
              <button
                onClick={() => seekRelative(10)}
                className="p-1.5 rounded-full hover:bg-white/10 transition text-neutral-300 hover:text-white"
                title="Maju 10 Detik (L)"
              >
                <RotateCw className="w-4 h-4" />
              </button>

              {/* Volume & Slider */}
              <div className="flex items-center group/vol">
                <button
                  onClick={toggleMute}
                  className="p-1.5 rounded-full hover:bg-white/10 transition text-neutral-300 hover:text-white"
                  title={isMuted ? 'Batal Bisukan (M)' : 'Bisukan (M)'}
                >
                  {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                  className="w-0 group-hover/vol:w-16 transition-all duration-200 accent-[#ff0000] cursor-pointer ml-1 h-1 bg-white/30 rounded"
                />
              </div>

              {/* Current Time / Total Duration */}
              <div className="text-xs font-mono text-neutral-300 select-none ml-1">
                <span>{formatTime(currentTime)}</span>
                <span className="mx-1 text-neutral-500">/</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Right Controls: Settings (Resolusi/Server), Fullscreen */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {/* Settings Gear (Resolusi & Server switcher) */}
              <button
                onClick={() => {
                  setIsSettingsOpen(!isSettingsOpen);
                  setSettingsView('main');
                }}
                className={`p-1.5 rounded-full transition ${
                  isSettingsOpen ? 'bg-white/20 text-white' : 'text-neutral-300 hover:text-white hover:bg-white/10'
                }`}
                title="Setelan Resolusi & Server"
              >
                <Settings className={`w-4 h-4 ${isSettingsOpen ? 'rotate-45' : ''} transition-transform duration-200`} />
              </button>

              {/* Fullscreen Toggle */}
              <button
                onClick={toggleFullscreen}
                className="p-1.5 rounded-full hover:bg-white/10 transition text-neutral-300 hover:text-white"
                title={isFullscreen ? 'Keluar Layar Penuh (F)' : 'Layar Penuh (F)'}
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Direct Download Options */}
      {downloads.length > 0 && (
        <div className="rounded-xl border border-neutral-800 bg-[#141414] p-4">
          <div className="flex items-center gap-2 mb-3">
            <Download className="w-4 h-4 text-neutral-400" />
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Tautan Download Video
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {downloads.map((dl, idx) => (
              <a
                key={idx}
                href={dl.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-medium text-neutral-300 hover:text-white hover:bg-neutral-800 hover:border-neutral-700 transition"
              >
                <Download className="w-3 h-3 text-neutral-400" />
                <span>{dl.quality}</span>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
