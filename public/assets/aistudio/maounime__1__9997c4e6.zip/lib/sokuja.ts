import * as cheerio from 'cheerio';

const SOKUJA_BASE = 'https://x6-sokuja-uk.translate.goog';
const TRANSLATE_PARAMS = '_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=zh-TW';

export interface AnimeCard {
  id?: string | number;
  slug: string;
  animeSlug?: string;
  title: string;
  cover: string;
  score?: string | number;
  episode?: string;
  episodeNumber?: number;
  type?: string;
  status?: string;
  year?: number | string;
}

export interface FeaturedAnime {
  id?: string | number;
  slug: string;
  title: string;
  backdrop: string;
  poster?: string;
  rating: string;
  type: string;
  studio: string;
  status: string;
  synopsis: string;
  genres: string[];
  firstEpisodeSlug?: string;
}

export interface AnimeDetail {
  slug: string;
  title: string;
  backdrop: string;
  poster: string;
  rating: string;
  type: string;
  status: string;
  year: string;
  season: string;
  studio: string;
  director?: string;
  producer?: string;
  synopsis: string;
  genres: string[];
  episodes: EpisodeItem[];
}

export interface EpisodeItem {
  id?: string;
  slug: string;
  title: string;
  number: number;
  date?: string;
}

export interface VideoMirror {
  id: number | string;
  serverName: string;
  quality: string;
  streamUrl: string;
  originalUrl: string;
  embedType: string;
}

export interface DownloadLink {
  quality: string;
  url: string;
}

export interface EpisodeStreamData {
  title: string;
  episodeNumber?: number;
  animeTitle: string;
  animeSlug: string;
  episodeSlug: string;
  episodeId?: string;
  mirrors: VideoMirror[];
  downloads: DownloadLink[];
  episodes: EpisodeItem[];
  prevEpisodeSlug?: string | null;
  nextEpisodeSlug?: string | null;
}

// Clean any brand or watermarks from text
export function sanitizeBrandText(text?: string | null): string {
  if (!text) return '';
  return text
    .replace(/sokuja(?:\.net|\.id|\.uk)?/gi, 'Maounime')
    .replace(/SOKUJA\.NET/gi, 'Maounime')
    .replace(/SOKUJA/gi, 'Maounime')
    .replace(/\s+/g, ' ')
    .trim();
}

// Convert image to clean proxy URL
export function formatImageUrl(url?: string | null): string {
  if (!url) return '';
  let clean = url.trim();

  // If Next.js image proxy URL
  if (clean.includes('/_next/image')) {
    const match = clean.match(/[?&]url=([^&]+)/);
    if (match && match[1]) {
      clean = decodeURIComponent(match[1]);
    }
  }

  // If protocol-relative
  if (clean.startsWith('//')) {
    clean = 'https:' + clean;
  } else if (clean.startsWith('/')) {
    clean = `https://x6.sokuja.uk${clean}`;
  }

  clean = clean.replace(/(\?|&)_x_tr_[^=]+=[^&]*/g, '');

  return `/api/image?url=${encodeURIComponent(clean)}`;
}

// --- In-Memory Caches & Concurrency Control ---
interface CacheEntry<T> {
  data: T;
  timestamp: number;
}

const htmlCache = new Map<string, CacheEntry<string>>();
const pendingFetches = new Map<string, Promise<string>>();

const homeDataCache: { entry: CacheEntry<{ featured: FeaturedAnime | null; latest: AnimeCard[] }> | null } = { entry: null };
const detailDataCache = new Map<string, CacheEntry<AnimeDetail>>();
const streamDataCache = new Map<string, CacheEntry<EpisodeStreamData>>();
const searchDataCache = new Map<string, CacheEntry<AnimeCard[]>>();

let activeRequests = 0;
const MAX_CONCURRENT_REQUESTS = 2;
const requestQueue: Array<() => void> = [];

function acquireRequestSlot(): Promise<void> {
  if (activeRequests < MAX_CONCURRENT_REQUESTS) {
    activeRequests++;
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    requestQueue.push(() => {
      activeRequests++;
      resolve();
    });
  });
}

function releaseRequestSlot() {
  activeRequests--;
  if (requestQueue.length > 0) {
    const next = requestQueue.shift();
    if (next) setTimeout(next, 100);
  }
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function fetchHtml(path: string, ttlMs: number = 10 * 60 * 1000): Promise<string | null> {
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  const separator = cleanPath.includes('?') ? '&' : '?';
  const url = `${SOKUJA_BASE}${cleanPath}${separator}${TRANSLATE_PARAMS}`;

  const cached = htmlCache.get(cleanPath);
  if (cached && Date.now() - cached.timestamp < ttlMs) {
    return cached.data || null;
  }

  if (pendingFetches.has(cleanPath)) {
    return await pendingFetches.get(cleanPath)!;
  }

  const fetchPromise = (async () => {
    await acquireRequestSlot();
    try {
      let attempts = 0;

      while (attempts < 2) {
        attempts++;
        try {
          const res = await fetch(url, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
              'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            },
          });

          if (res.status === 404) {
            htmlCache.set(cleanPath, { data: '', timestamp: Date.now() });
            return null;
          }

          if (res.status === 429) {
            if (cached && cached.data) return cached.data;
            await sleep(800 * attempts);
            continue;
          }

          if (!res.ok) {
            if (cached && cached.data) return cached.data;
            return null;
          }

          const html = await res.text();
          htmlCache.set(cleanPath, {
            data: html,
            timestamp: Date.now(),
          });
          return html;
        } catch {
          if (cached && cached.data) return cached.data;
          await sleep(400);
        }
      }

      if (cached && cached.data) return cached.data;
      return null;
    } finally {
      releaseRequestSlot();
      pendingFetches.delete(cleanPath);
    }
  })();

  pendingFetches.set(cleanPath, fetchPromise as Promise<any>);
  return await fetchPromise;
}

// Fallback seed catalog
const FALLBACK_LATEST: AnimeCard[] = [
  {
    slug: 'tokyo-revengers-santen-sensou-hen-episode-4-subtitle-indonesia',
    animeSlug: 'tokyo-revengers-santen-sensou-hen-subtitle-indonesia',
    title: 'Tokyo Revengers: Santen Sensou-hen',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/10/tokyo-revengers-santen-sensou-hen-episode-4-subtit-1792781413510.webp'),
    score: '8.4',
    episode: 'EP 4',
    episodeNumber: 4,
    type: 'TV',
  },
  {
    slug: 'tougen-anki-nikko-kegon-no-taki-hen-episode-4-subtitle-indonesia',
    animeSlug: 'tougen-anki-nikko-kegon-no-taki-hen-subtitle-indonesia',
    title: 'Tougen Anki: Nikko Kegon no Taki-hen',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/10/tougen-anki-nikko-kegon-no-taki-hen-episode-4-subt-1792773167707.webp'),
    score: '8.1',
    episode: 'EP 4',
    episodeNumber: 4,
    type: 'TV',
  },
  {
    slug: 'hotaru-no-yomeiri-episode-3-subtitle-indonesia',
    animeSlug: 'hotaru-no-yomeiri-subtitle-indonesia',
    title: 'Hotaru no Yomeiri',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/10/hotaru-no-yomeiri-episode-3-subtitle-indonesia-1792772476449.webp'),
    score: '8.5',
    episode: 'EP 3',
    episodeNumber: 3,
    type: 'TV',
  },
  {
    slug: 'toaru-anbu-no-item-episode-3-subtitle-indonesia',
    animeSlug: 'toaru-anbu-no-item-subtitle-indonesia',
    title: 'Toaru Anbu no Item',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/10/toaru-anbu-no-item-episode-3-subtitle-indonesia-1792769624392.webp'),
    score: '8.0',
    episode: 'EP 3',
    episodeNumber: 3,
    type: 'TV',
  },
  {
    slug: 'kusuriya-no-hitorigoto-season-3-episode-4-subtitle-indonesia',
    animeSlug: 'kusuriya-no-hitorigoto-season-3-subtitle-indonesia',
    title: 'Kusuriya no Hitorigoto Season 3',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/10/kusuriya-no-hitorigoto-season-3-episode-4-subtitle-1792768313080.webp'),
    score: '8.8',
    episode: 'EP 4',
    episodeNumber: 4,
    type: 'TV',
  },
  {
    slug: 'hyouken-no-majutsushi-ga-sekai-wo-suberu-ii-episode-3-subtitle-indonesia',
    animeSlug: 'hyouken-no-majutsushi-ga-sekai-wo-suberu-ii-subtitle-indonesia',
    title: 'Hyouken no Majutsushi ga Sekai wo Suberu II',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/10/hyouken-no-majutsushi-ga-sekai-wo-suberu-ii-episod-1792688795246.webp'),
    score: '7.9',
    episode: 'EP 3',
    episodeNumber: 3,
    type: 'TV',
  },
  {
    slug: 'cyberpunk-edgerunners-2-episode-8-subtitle-indonesia',
    animeSlug: 'cyberpunk-edgerunners-2-subtitle-indonesia',
    title: 'Cyberpunk: Edgerunners 2',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/10/cyberpunk-edgerunners-2-episode-8-subtitle-indones-1792509097357.webp'),
    score: '8.7',
    episode: 'EP 8',
    episodeNumber: 8,
    type: 'ONA',
  },
  {
    slug: 'one-piece-episode-1180-subtitle-indonesia',
    animeSlug: 'one-piece-subtitle-indonesia',
    title: 'One Piece',
    cover: formatImageUrl('https://gbr.sokuja.uk/wp-content/uploads/2022/08/sokuja-one-piece-indo.jpg'),
    score: '8.9',
    episode: 'EP 1180',
    episodeNumber: 1180,
    type: 'TV',
  },
  {
    slug: 'black-clover-season-2-episode-12-subtitle-indonesia',
    animeSlug: 'black-clover-season-2-subtitle-indonesia',
    title: 'Black Clover Season 2',
    cover: formatImageUrl('https://x6.sokuja.uk/uploads/2026/09/sokuja-black-clover-season-2-subtitle-indonesia-12-1790693546723.webp'),
    score: '8.3',
    episode: 'EP 12',
    episodeNumber: 12,
    type: 'TV',
  },
];

export async function getHomeData(): Promise<{
  featured: FeaturedAnime | null;
  latest: AnimeCard[];
}> {
  if (homeDataCache.entry && Date.now() - homeDataCache.entry.timestamp < 15 * 60 * 1000) {
    return homeDataCache.entry.data;
  }

  try {
    const html = await fetchHtml('/', 15 * 60 * 1000);
    if (!html) {
      if (homeDataCache.entry) return homeDataCache.entry.data;
      throw new Error('Home html unavailable');
    }
    const $ = cheerio.load(html);

    const latest: AnimeCard[] = [];
    const headingEl = $("h2:contains('Update Terbaru')");
    let container: cheerio.Cheerio<any> = headingEl.parent().parent();
    if (!container || container.find("a[href*='-episode-']").length === 0) {
      container = headingEl.closest('section, div.mb-8, main');
    }

    const cardElements = container && container.find("a[href*='-episode-']").length > 0 
      ? container.find("a[href*='-episode-']") 
      : $("a[href*='-episode-']");

    const seenSlugs = new Set<string>();

    cardElements.each((_, el) => {
      const href = $(el).attr('href') || '';
      const urlObj = new URL(href, 'https://x6.sokuja.uk');
      const cleanPath = urlObj.pathname.replace(/^\/|\/$/g, '');
      if (!cleanPath || !cleanPath.includes('-episode-') || seenSlugs.has(cleanPath)) return;
      seenSlugs.add(cleanPath);

      const imgEl = $(el).find('img').first();
      const rawImg = imgEl.attr('src') || imgEl.attr('data-src') || imgEl.attr('srcset') || '';

      const fullText = $(el).text().trim().replace(/\s+/g, ' ');
      const titleEl = $(el).find('h3, h2, .title, p.font-semibold, div.font-medium').first();
      let title = titleEl.text().trim();
      if (!title) {
        title = imgEl.attr('alt')?.trim() || fullText.replace(/EP\s*\d+|TV|Ongoing|·.*$/g, '').trim();
      }
      title = sanitizeBrandText(title.replace(/\s*Episode\s*\d+.*$/i, '').trim());

      const epMatch = cleanPath.match(/-episode-(\d+)/i) || fullText.match(/(?:EP|Episode)\s*(\d+)/i);
      const epNum = epMatch ? parseInt(epMatch[1], 10) : undefined;
      const episode = epNum ? `EP ${epNum}` : 'EP';

      const scoreMatch = fullText.match(/\b([789]\.\d{1,2})\b/);
      const score = scoreMatch ? scoreMatch[1] : '8.2';

      let animeSlug = cleanPath.replace(/-episode-\d+/, '');
      if (!animeSlug.includes('subtitle-indonesia')) {
        animeSlug = `${animeSlug}-subtitle-indonesia`;
      }

      latest.push({
        slug: cleanPath,
        animeSlug,
        title,
        cover: formatImageUrl(rawImg),
        score,
        episode,
        episodeNumber: epNum,
        type: 'TV',
      });
    });

    const finalLatest = latest.length > 0 ? latest.slice(0, 24) : FALLBACK_LATEST;
    const top = finalLatest[0];
    const featured: FeaturedAnime = {
      slug: top.animeSlug || top.slug,
      title: top.title,
      backdrop: top.cover,
      rating: typeof top.score === 'string' ? top.score : '8.5',
      type: 'TV',
      studio: 'Studio Animasi',
      status: 'Ongoing',
      synopsis: 'Streaming dan download anime subtitle Indonesia terbaru dengan kualitas jernih HD dan server cepat.',
      genres: ['Action', 'Adventure', 'Fantasy'],
      firstEpisodeSlug: top.slug,
    };

    const result = { featured, latest: finalLatest };
    homeDataCache.entry = { data: result, timestamp: Date.now() };
    return result;
  } catch (error) {
    console.error('getHomeData error, using fallback:', error);
    if (homeDataCache.entry) {
      return homeDataCache.entry.data;
    }
    const fallbackTop = FALLBACK_LATEST[0];
    return {
      featured: {
        slug: fallbackTop.animeSlug || fallbackTop.slug,
        title: fallbackTop.title,
        backdrop: fallbackTop.cover,
        rating: '8.5',
        type: 'TV',
        studio: 'Studio Animasi',
        status: 'Ongoing',
        synopsis: 'Streaming dan download anime subtitle Indonesia terbaru kualitas HD.',
        genres: ['Action', 'Fantasy'],
        firstEpisodeSlug: fallbackTop.slug,
      },
      latest: FALLBACK_LATEST,
    };
  }
}

// AniList global search helper for 100% comprehensive catalog
async function searchAniList(query: string): Promise<AnimeCard[]> {
  const graphqlQuery = `
    query ($search: String) {
      Page(perPage: 12) {
        media(search: $search, type: ANIME, sort: SEARCH_MATCH) {
          id
          title {
            romaji
            english
          }
          coverImage {
            large
            extraLarge
          }
          averageScore
          episodes
          format
          status
          seasonYear
        }
      }
    }
  `;

  try {
    const res = await fetch('https://graphql.anilist.co', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: graphqlQuery, variables: { search: query } }),
      next: { revalidate: 3600 },
    });

    if (!res.ok) return [];
    const json = await res.json();
    const mediaList = json.data?.Page?.media;
    if (!Array.isArray(mediaList)) return [];

    return mediaList.map((m: any) => {
      const cleanTitle = sanitizeBrandText(m.title.english || m.title.romaji || 'Anime');
      const slug = cleanTitle
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '') + '-subtitle-indonesia';

      const score = m.averageScore ? (m.averageScore / 10).toFixed(1) : '8.0';

      return {
        id: m.id,
        slug,
        animeSlug: slug,
        title: cleanTitle,
        cover: m.coverImage?.extraLarge || m.coverImage?.large || '',
        score,
        type: m.format || 'TV',
        status: m.status === 'FINISHED' ? 'Completed' : 'Ongoing',
        year: m.seasonYear,
      };
    });
  } catch (err) {
    console.error('AniList search error:', err);
    return [];
  }
}

export async function searchAnime(query: string): Promise<AnimeCard[]> {
  const q = query.trim().toLowerCase();
  if (!q) return [];

  const cached = searchDataCache.get(q);
  if (cached && Date.now() - cached.timestamp < 10 * 60 * 1000) {
    return cached.data;
  }

  const results: AnimeCard[] = [];
  const seenTitles = new Set<string>();

  // 1. Search primary source
  try {
    const url = `${SOKUJA_BASE}/api/search?q=${encodeURIComponent(q)}&${TRANSLATE_PARAMS}`;
    await acquireRequestSlot();
    let res: Response | null = null;
    try {
      res = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)',
          'Accept': 'application/json',
        },
      });
    } finally {
      releaseRequestSlot();
    }

    if (res && res.ok) {
      const data = await res.json();
      if (Array.isArray(data.results)) {
        for (const item of data.results) {
          const t = sanitizeBrandText(item.title || '');
          if (!t || seenTitles.has(t.toLowerCase())) continue;
          seenTitles.add(t.toLowerCase());

          results.push({
            id: item.id,
            slug: item.slug || '',
            animeSlug: item.slug || '',
            title: t,
            cover: formatImageUrl(item.coverUrl || item.thumbnailUrl),
            score: item.score || '8.0',
            type: item.type || 'TV',
            status: item.status || 'Ongoing',
            year: item.year,
          });
        }
      }
    }
  } catch (err) {
    console.warn('Primary search failed, proceeding to global catalog:', err);
  }

  // 2. Query AniList for comprehensive catalog (Naruto, Monster, etc.)
  try {
    const aniListResults = await searchAniList(q);
    for (const item of aniListResults) {
      const key = item.title.toLowerCase();
      if (!seenTitles.has(key)) {
        seenTitles.add(key);
        results.push(item);
      }
    }
  } catch (err) {
    console.warn('AniList search failed:', err);
  }

  // 3. Match from local fallback catalog if needed
  for (const item of FALLBACK_LATEST) {
    if (item.title.toLowerCase().includes(q) && !seenTitles.has(item.title.toLowerCase())) {
      seenTitles.add(item.title.toLowerCase());
      results.push(item);
    }
  }

  searchDataCache.set(q, { data: results, timestamp: Date.now() });
  return results;
}

// Fetch complete anime detail from AniList as backup / comprehensive catalog
async function getAniListAnimeDetail(cleanTitleOrSlug: string): Promise<AnimeDetail | null> {
  const searchTerm = cleanTitleOrSlug
    .replace(/-subtitle-indonesia.*$/i, '')
    .replace(/-/g, ' ')
    .trim();

  const graphqlQuery = `
    query ($search: String) {
      Media(search: $search, type: ANIME, sort: SEARCH_MATCH) {
        id
        title {
          romaji
          english
        }
        coverImage {
          extraLarge
          large
        }
        bannerImage
        averageScore
        episodes
        format
        status
        seasonYear
        season
        genres
        studios(isMain: true) {
          nodes {
            name
          }
        }
        description
      }
    }
  `;

  try {
    const res = await fetch('https://graphql.anilist.co', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: graphqlQuery, variables: { search: searchTerm } }),
      next: { revalidate: 3600 },
    });

    if (!res.ok) return null;
    const json = await res.json();
    const m = json.data?.Media;
    if (!m) return null;

    const title = sanitizeBrandText(m.title.english || m.title.romaji || searchTerm);
    const score = m.averageScore ? (m.averageScore / 10).toFixed(1) : '8.4';
    const totalEps = m.episodes || 12;
    const baseSlug = cleanTitleOrSlug.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');

    const episodes: EpisodeItem[] = [];
    for (let i = totalEps; i >= 1; i--) {
      episodes.push({
        slug: `${baseSlug}-episode-${i}-subtitle-indonesia`,
        title: `${title} Episode ${i}`,
        number: i,
      });
    }

    const studio = m.studios?.nodes?.[0]?.name || 'Studio Animasi';
    const synopsis = (m.description || 'Streaming dan download anime subtitle Indonesia terbaru.')
      .replace(/<[^>]*>/g, '')
      .replace(/&quot;/g, '"');

    return {
      slug: cleanTitleOrSlug,
      title,
      backdrop: m.bannerImage || m.coverImage?.extraLarge || m.coverImage?.large || '',
      poster: m.coverImage?.extraLarge || m.coverImage?.large || '',
      rating: score,
      type: m.format || 'TV',
      status: m.status === 'FINISHED' ? 'Completed' : 'Ongoing',
      year: m.seasonYear ? String(m.seasonYear) : '2024',
      season: m.season ? `${m.season} ${m.seasonYear || ''}`.trim() : 'TV Series',
      studio,
      synopsis,
      genres: m.genres || ['Action', 'Drama'],
      episodes,
    };
  } catch (err) {
    console.error('getAniListAnimeDetail error:', err);
    return null;
  }
}

export async function getAnimeDetail(slug: string): Promise<AnimeDetail | null> {
  const cleanSlug = slug.replace(/^\/?anime\/?/, '').replace(/\/+$/, '');

  const cached = detailDataCache.get(cleanSlug);
  if (cached && Date.now() - cached.timestamp < 15 * 60 * 1000) {
    return cached.data;
  }

  // 1. Try scraping primary source
  try {
    const html = await fetchHtml(`/anime/${cleanSlug}/`, 15 * 60 * 1000);
    if (html) {
      const $ = cheerio.load(html);

      let title = $('h1').first().text().trim();
      title = title.replace(/\s*Subtitle Indonesia.*$/i, '').trim();
      if (!title) {
        title = $('meta[property="og:title"]').attr('content')?.replace(/\s*Subtitle Indonesia.*$/i, '').trim() || cleanSlug.replace(/-/g, ' ');
      }
      title = sanitizeBrandText(title);

      const posterMeta = $('meta[property="og:image"]').attr('content') || '';
      const poster = formatImageUrl(posterMeta);
      const backdrop = poster;

      let synopsis = $('div.rounded-xl p, p.synopsis, article p').first().text().trim();
      if (!synopsis) {
        synopsis = $('meta[name="description"]').attr('content') || '';
      }
      synopsis = sanitizeBrandText(synopsis.replace(/^Nonton\s*&\s*download anime [^.]+\.\s*/i, ''));

      let rating = $('span:contains("."), div:contains("Rating")').first().text().replace(/[^0-9.]/g, '').trim();
      if (!rating || rating.length > 4) {
        const ratingMatch = html.match(/\\?"score\\?":\s*\\?"?([0-9.]+)\\?"?/);
        rating = ratingMatch ? ratingMatch[1] : '8.3';
      }

      let type = 'TV';
      let status = 'Ongoing';
      let year = '2026';
      let season = 'Fall 2026';
      let studio = 'Studio Animasi';
      let director = '';
      let producer = '';

      $('dt, span.font-semibold, div.font-medium').each((_, el) => {
        const key = $(el).text().trim().toLowerCase();
        const val = $(el).next().text().trim() || $(el).parent().find('dd').text().trim();
        if (!val) return;

        if (key.includes('tipe') || key.includes('type')) type = val;
        if (key.includes('status')) status = val;
        if (key.includes('tahun') || key.includes('year')) year = val;
        if (key.includes('musim') || key.includes('season')) season = val;
        if (key.includes('studio')) studio = sanitizeBrandText(val);
        if (key.includes('sutradara') || key.includes('director')) director = val;
        if (key.includes('produser') || key.includes('producer')) producer = val;
      });

      const genres: string[] = [];
      $("a[href*='/genre/']").each((_, el) => {
        const g = $(el).text().trim();
        if (g && !genres.includes(g)) genres.push(g);
      });
      if (genres.length === 0) {
        genres.push('Action', 'Fantasy', 'Animation');
      }

      const episodes: EpisodeItem[] = [];
      const seenEpSlugs = new Set<string>();

      const epRegex = /\\?"id\\?":\s*(\d+),\s*\\?"slug\\?":\s*\\?"([^\\"]+)\\?",\s*\\?"title\\?":\s*\\?"([^\\"]+)\\?",\s*\\?"episodeNumber\\?":\s*(\d+)/g;
      let m;
      while ((m = epRegex.exec(html)) !== null) {
        const epId = m[1];
        const epSlug = m[2];
        const epTitle = sanitizeBrandText(m[3]);
        const epNum = parseInt(m[4], 10);
        if (!seenEpSlugs.has(epSlug)) {
          seenEpSlugs.add(epSlug);
          episodes.push({
            id: epId,
            slug: epSlug,
            title: epTitle,
            number: epNum,
          });
        }
      }

      if (episodes.length === 0) {
        const epHeading = $("h2:contains('Daftar Episode'), h3:contains('Daftar Episode')");
        const epSection: cheerio.Cheerio<any> = epHeading.closest('div, section');
        const targetLinks = epSection && epSection.find("a[href*='-episode-']").length > 0 
          ? epSection.find("a[href*='-episode-']") 
          : $("a[href*='-episode-']");

        targetLinks.each((_, el) => {
          const rawHref = $(el).attr('href') || '';
          const urlObj = new URL(rawHref, 'https://x6.sokuja.uk');
          const epSlug = urlObj.pathname.replace(/^\/|\/$/g, '');
          if (!epSlug || !epSlug.includes('-episode-') || seenEpSlugs.has(epSlug)) return;
          seenEpSlugs.add(epSlug);

          const epText = $(el).text().trim().replace(/\s+/g, ' ');
          const numMatch = epSlug.match(/-episode-(\d+)/i) || epText.match(/(?:ep|episode)\s*(\d+)/i);
          const epNum = numMatch ? parseInt(numMatch[1], 10) : episodes.length + 1;

          episodes.push({
            slug: epSlug,
            title: sanitizeBrandText(epText.replace(/(\d+\s*(?:hari|jam|menit|minggu|bulan)\s*lalu).*$/i, '').trim()) || `Episode ${epNum}`,
            number: epNum,
          });
        });
      }

      episodes.sort((a, b) => b.number - a.number);

      if (episodes.length > 0 && title) {
        const detail: AnimeDetail = {
          slug: cleanSlug,
          title,
          backdrop,
          poster,
          rating,
          type,
          status,
          year,
          season,
          studio,
          director,
          producer,
          synopsis,
          genres,
          episodes,
        };

        detailDataCache.set(cleanSlug, { data: detail, timestamp: Date.now() });
        return detail;
      }
    }
  } catch {
    // Seamlessly fall through to global catalog
  }

  // 2. Global Catalog Lookup (For Naruto, Monster, etc.)
  const globalDetail = await getAniListAnimeDetail(cleanSlug);
  if (globalDetail) {
    detailDataCache.set(cleanSlug, { data: globalDetail, timestamp: Date.now() });
    return globalDetail;
  }

  // 3. Fallback catalog check
  const fallbackMatch = FALLBACK_LATEST.find(
    (item) => item.animeSlug === cleanSlug || item.slug === cleanSlug
  );
  if (fallbackMatch) {
    const defaultDetail: AnimeDetail = {
      slug: cleanSlug,
      title: fallbackMatch.title,
      backdrop: fallbackMatch.cover,
      poster: fallbackMatch.cover,
      rating: typeof fallbackMatch.score === 'string' ? fallbackMatch.score : '8.4',
      type: fallbackMatch.type || 'TV',
      status: 'Ongoing',
      year: '2026',
      season: 'Fall 2026',
      studio: 'Studio Animasi',
      synopsis: 'Streaming dan download anime subtitle Indonesia terbaru dengan kualitas jernih HD.',
      genres: ['Action', 'Fantasy'],
      episodes: [
        {
          slug: fallbackMatch.slug,
          title: `${fallbackMatch.title} Episode ${fallbackMatch.episodeNumber || 1}`,
          number: fallbackMatch.episodeNumber || 1,
        },
      ],
    };
    return defaultDetail;
  }

  return null;
}

export async function getEpisodeStream(episodeSlug: string): Promise<EpisodeStreamData | null> {
  const cleanSlug = episodeSlug.replace(/^\/+|\/+$/g, '');

  const cached = streamDataCache.get(cleanSlug);
  if (cached && Date.now() - cached.timestamp < 15 * 60 * 1000) {
    return cached.data;
  }

  try {
    const html = await fetchHtml(`/${cleanSlug}/`, 15 * 60 * 1000);
    if (html) {
      const $ = cheerio.load(html);

      let title = $('h1').first().text().trim();
      title = sanitizeBrandText(title.replace(/\s*Subtitle Indonesia.*$/i, '').trim());

      const epIdMatch = html.match(/\\?"episodeId\\?":\s*(\d+)/);
      const episodeId = epIdMatch ? epIdMatch[1] : undefined;

      const numMatch = cleanSlug.match(/-episode-(\d+)/i) || title.match(/(?:ep|episode)\s*(\d+)/i);
      const episodeNumber = numMatch ? parseInt(numMatch[1], 10) : undefined;

      let animeSlug = cleanSlug.replace(/-episode-\d+/, '');
      if (!animeSlug.includes('subtitle-indonesia')) {
        animeSlug = `${animeSlug}-subtitle-indonesia`;
      }
      const animeTitle = sanitizeBrandText(title.replace(/\s*Episode\s*\d+.*$/i, '').trim()) || 'Anime';

      const mirrors: VideoMirror[] = [];

      if (episodeId) {
        try {
          await acquireRequestSlot();
          let mirrorRes: Response | null = null;
          try {
            mirrorRes = await fetch(`${SOKUJA_BASE}/api/video-mirrors?e=${episodeId}&${TRANSLATE_PARAMS}`, {
              headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)',
                'Accept': 'application/json',
              },
            });
          } finally {
            releaseRequestSlot();
          }

          if (mirrorRes && mirrorRes.ok) {
            const mirrorData = await mirrorRes.json();
            if (Array.isArray(mirrorData.mirrors)) {
              for (let i = 0; i < mirrorData.mirrors.length; i++) {
                const m = mirrorData.mirrors[i];
                const original = m.embedUrl || '';
                const fixed = original.replace('storages.sokuja.uk', 'storages.sokuja.id');
                
                const cleanServerName = i === 0 ? 'Server Utama' : `Server Cadangan ${i}`;

                mirrors.push({
                  id: m.id || i + 1,
                  serverName: cleanServerName,
                  quality: m.quality || '720p',
                  streamUrl: fixed,
                  originalUrl: original,
                  embedType: m.embedType || 'mp4',
                });
              }
            }
          }
        } catch {
          // fallback mirrors below
        }
      }

      if (mirrors.length === 0) {
        const baseSlug = cleanSlug.replace('-subtitle-indonesia', '');
        const epNum = episodeNumber || 1;
        mirrors.push(
          {
            id: 1,
            serverName: 'Server Utama',
            quality: '1080p',
            streamUrl: `https://storages.sokuja.id/2026-fall/${baseSlug}/NET-${epNum}.1080p.mp4`,
            originalUrl: '',
            embedType: 'mp4',
          },
          {
            id: 2,
            serverName: 'Server Utama',
            quality: '720p',
            streamUrl: `https://storages.sokuja.id/2026-fall/${baseSlug}/NET-${epNum}.720p.mp4`,
            originalUrl: '',
            embedType: 'mp4',
          },
          {
            id: 3,
            serverName: 'Server Cadangan',
            quality: '480p',
            streamUrl: `https://storages.sokuja.id/2026-fall/${baseSlug}/NET-${epNum}.480p.mp4`,
            originalUrl: '',
            embedType: 'mp4',
          }
        );
      }

      const downloads: DownloadLink[] = [];
      for (const m of mirrors) {
        if (m.streamUrl.endsWith('.mp4')) {
          downloads.push({
            quality: `${m.quality} MP4`,
            url: m.streamUrl,
          });
        }
      }

      const episodes: EpisodeItem[] = [];
      const seen = new Set<string>();
      $("a[href*='-episode-']").each((_, el) => {
        const rawHref = $(el).attr('href') || '';
        const urlObj = new URL(rawHref, 'https://x6.sokuja.uk');
        const s = urlObj.pathname.replace(/^\/|\/$/g, '');
        if (s && s.includes('-episode-') && !seen.has(s)) {
          seen.add(s);
          const epN = s.match(/-episode-(\d+)/i);
          episodes.push({
            slug: s,
            title: `Episode ${epN ? epN[1] : ''}`,
            number: epN ? parseInt(epN[1], 10) : 0,
          });
        }
      });
      episodes.sort((a, b) => a.number - b.number);

      let prevEpisodeSlug: string | null = null;
      let nextEpisodeSlug: string | null = null;

      if (episodeNumber && episodes.length > 0) {
        const currentIndex = episodes.findIndex((e) => e.number === episodeNumber || e.slug === cleanSlug);
        if (currentIndex > 0) {
          prevEpisodeSlug = episodes[currentIndex - 1].slug;
        }
        if (currentIndex >= 0 && currentIndex < episodes.length - 1) {
          nextEpisodeSlug = episodes[currentIndex + 1].slug;
        }
      }

      const streamData: EpisodeStreamData = {
        title: title || `${animeTitle} Episode ${episodeNumber || 1}`,
        episodeNumber,
        animeTitle,
        animeSlug,
        episodeSlug: cleanSlug,
        episodeId,
        mirrors,
        downloads,
        episodes,
        prevEpisodeSlug,
        nextEpisodeSlug,
      };

      streamDataCache.set(cleanSlug, { data: streamData, timestamp: Date.now() });
      return streamData;
    }
  } catch {
    // Seamless fallback below
  }

  if (cached) return cached.data;

    const numMatch = cleanSlug.match(/-episode-(\d+)/i);
    const epNum = numMatch ? parseInt(numMatch[1], 10) : 1;
    let animeSlug = cleanSlug.replace(/-episode-\d+/, '');
    if (!animeSlug.includes('subtitle-indonesia')) {
      animeSlug = `${animeSlug}-subtitle-indonesia`;
    }
    const cleanTitle = sanitizeBrandText(cleanSlug.replace(/-subtitle-indonesia.*$/, '').replace(/-/g, ' '));

    const fallbackStreamData: EpisodeStreamData = {
      title: `${cleanTitle} Episode ${epNum}`,
      episodeNumber: epNum,
      animeTitle: cleanTitle,
      animeSlug,
      episodeSlug: cleanSlug,
      mirrors: [
        {
          id: 1,
          serverName: 'Server Utama',
          quality: '1080p',
          streamUrl: `https://storages.sokuja.id/2026-fall/${animeSlug}/NET-${epNum}.1080p.mp4`,
          originalUrl: '',
          embedType: 'mp4',
        },
        {
          id: 2,
          serverName: 'Server Utama',
          quality: '720p',
          streamUrl: `https://storages.sokuja.id/2026-fall/${animeSlug}/NET-${epNum}.720p.mp4`,
          originalUrl: '',
          embedType: 'mp4',
        },
        {
          id: 3,
          serverName: 'Server Cadangan',
          quality: '480p',
          streamUrl: `https://storages.sokuja.id/2026-fall/${animeSlug}/NET-${epNum}.480p.mp4`,
          originalUrl: '',
          embedType: 'mp4',
        },
      ],
      downloads: [
        {
          quality: '720p MP4',
          url: `https://storages.sokuja.id/2026-fall/${animeSlug}/NET-${epNum}.720p.mp4`,
        },
      ],
      episodes: [
        {
          slug: cleanSlug,
          title: `Episode ${epNum}`,
          number: epNum,
        },
      ],
      prevEpisodeSlug: epNum > 1 ? cleanSlug.replace(`-episode-${epNum}`, `-episode-${epNum - 1}`) : null,
      nextEpisodeSlug: cleanSlug.replace(`-episode-${epNum}`, `-episode-${epNum + 1}`),
    };

    return fallbackStreamData;
  }
