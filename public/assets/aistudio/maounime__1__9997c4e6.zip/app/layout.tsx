import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Maounime - Streaming Anime Subtitle Indonesia',
  description: 'Web streaming anime subtitle Indonesia terlengkap dan terupdate.',
  openGraph: {
    title: 'Maounime - Streaming Anime Subtitle Indonesia',
    description: 'Web streaming anime subtitle Indonesia terlengkap dan terupdate.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Maounime - Streaming Anime Subtitle Indonesia',
    description: 'Web streaming anime subtitle Indonesia terlengkap dan terupdate.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="id" className="dark">
      <body className="bg-[#0a0a0a] text-neutral-100 min-h-screen antialiased selection:bg-neutral-800 selection:text-white" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
