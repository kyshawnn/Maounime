import { NextRequest, NextResponse } from 'next/server';

interface CachedImage {
  buffer: Uint8Array;
  contentType: string;
  expires: number;
}

// In-memory image cache (max 200 items, 24 hours TTL)
const imageCache = new Map<string, CachedImage>();
const MAX_CACHE_ITEMS = 200;

// Simple semaphore / queue to limit concurrency to max 2 simultaneous image fetches
let activeImageFetches = 0;
const MAX_CONCURRENT_FETCHES = 2;
const waitQueue: Array<() => void> = [];

function acquireSlot(): Promise<void> {
  if (activeImageFetches < MAX_CONCURRENT_FETCHES) {
    activeImageFetches++;
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    waitQueue.push(() => {
      activeImageFetches++;
      resolve();
    });
  });
}

function releaseSlot() {
  activeImageFetches--;
  if (waitQueue.length > 0) {
    const next = waitQueue.shift();
    if (next) next();
  }
}

function getFallbackSvg(): NextResponse {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="600" viewBox="0 0 400 600" fill="#171717">
    <rect width="400" height="600" fill="#141414"/>
    <rect x="20" y="20" width="360" height="560" fill="none" stroke="#262626" stroke-width="2" rx="8"/>
    <text x="200" y="300" text-anchor="middle" fill="#737373" font-family="sans-serif" font-size="14" font-weight="600">MAOUNIME</text>
  </svg>`;
  return new NextResponse(svg, {
    headers: {
      'Content-Type': 'image/svg+xml',
      'Cache-Control': 'public, max-age=86400',
    },
  });
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const targetUrl = searchParams.get('url');

  if (!targetUrl) {
    return new NextResponse('Missing URL', { status: 400 });
  }

  // 1. Check in-memory cache first
  const cached = imageCache.get(targetUrl);
  if (cached && Date.now() < cached.expires) {
    return new NextResponse(cached.buffer as unknown as BodyInit, {
      headers: {
        'Content-Type': cached.contentType,
        'Cache-Control': 'public, max-age=604800, stale-while-revalidate=86400',
      },
    });
  }

  await acquireSlot();

  try {
    let fetchUrl = targetUrl;

    if (fetchUrl.includes('x6.sokuja.uk') || fetchUrl.includes('gbr.sokuja.uk')) {
      const u = new URL(fetchUrl);
      if (fetchUrl.includes('x6.sokuja.uk')) {
        fetchUrl = `https://x6-sokuja-uk.translate.goog${u.pathname}${u.search ? u.search + '&' : '?'}_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=zh-TW`;
      } else if (fetchUrl.includes('gbr.sokuja.uk')) {
        fetchUrl = `https://storages.sokuja.id${u.pathname}`;
      }
    }

    let res = await fetch(fetchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': 'https://x6.sokuja.uk/',
      },
    });

    if (!res.ok && res.status !== 429 && fetchUrl !== targetUrl) {
      res = await fetch(targetUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Referer': 'https://x6.sokuja.uk/',
        },
      });
    }

    if (!res.ok) {
      if (cached) {
        return new NextResponse(cached.buffer as unknown as BodyInit, {
          headers: {
            'Content-Type': cached.contentType,
            'Cache-Control': 'public, max-age=86400',
          },
        });
      }
      return getFallbackSvg();
    }

    const contentType = res.headers.get('content-type') || 'image/webp';
    const arrayBuffer = await res.arrayBuffer();
    const buffer = new Uint8Array(arrayBuffer);

    // Save in cache
    if (imageCache.size >= MAX_CACHE_ITEMS) {
      const firstKey = imageCache.keys().next().value;
      if (firstKey) imageCache.delete(firstKey);
    }
    imageCache.set(targetUrl, {
      buffer,
      contentType,
      expires: Date.now() + 24 * 60 * 60 * 1000,
    });

    return new NextResponse(buffer as unknown as BodyInit, {
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=604800, stale-while-revalidate=86400',
      },
    });
  } catch (error) {
    if (cached) {
      return new NextResponse(cached.buffer as unknown as BodyInit, {
        headers: {
          'Content-Type': cached.contentType,
          'Cache-Control': 'public, max-age=86400',
        },
      });
    }
    return getFallbackSvg();
  } finally {
    releaseSlot();
  }
}
