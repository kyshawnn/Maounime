import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, ChevronLeft, ChevronRight, Layers, Film } from 'lucide-react';
import Navbar from '@/components/Navbar';
import VideoPlayer from '@/components/VideoPlayer';
import { getEpisodeStream, getAnimeDetail } from '@/lib/sokuja';

interface PageProps {
  params: Promise<{ slug: string }>;
}

export const revalidate = 60; // 1 minute ISR

export default async function WatchPage({ params }: PageProps) {
  const { slug } = await params;
  const data = await getEpisodeStream(slug);

  if (!data) {
    notFound();
  }

  // Use episode list from data, or fallback to animeDetail if needed
  let fullEpisodes = data.episodes;
  if (!fullEpisodes || fullEpisodes.length === 0) {
    try {
      const animeDetail = await getAnimeDetail(data.animeSlug);
      if (animeDetail?.episodes && animeDetail.episodes.length > 0) {
        fullEpisodes = animeDetail.episodes;
      }
    } catch {
      // ignore
    }
  }
  if (!fullEpisodes || fullEpisodes.length === 0) {
    fullEpisodes = [
      {
        slug: data.episodeSlug,
        title: data.title,
        number: data.episodeNumber || 1,
      },
    ];
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-neutral-100 flex flex-col">
      <Navbar />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between gap-4 mb-4">
          <Link
            href={`/detail/${data.animeSlug}`}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs font-medium text-neutral-300 hover:text-white hover:border-neutral-700 transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Kembali ke Detail Anime</span>
          </Link>

          <span className="text-xs text-neutral-500 font-medium">
            Server Pemutar Video HD
          </span>
        </div>

        {/* Anime & Episode Title */}
        <div className="mb-4">
          <h1 className="text-lg sm:text-xl md:text-2xl font-bold tracking-tight text-white">
            {data.title}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1">
            {data.animeTitle} {data.episodeNumber ? `· Episode ${data.episodeNumber}` : ''}
          </p>
        </div>

        {/* Video Player */}
        <VideoPlayer
          title={data.title}
          mirrors={data.mirrors}
          downloads={data.downloads}
          animeTitle={data.animeTitle}
        />

        {/* Next / Previous Episode Navigation */}
        <div className="flex items-center justify-between gap-3 my-6 pt-4 border-t border-neutral-800">
          {data.prevEpisodeSlug ? (
            <Link
              href={`/watch/${data.prevEpisodeSlug}`}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs sm:text-sm font-medium text-neutral-200 hover:text-white hover:border-neutral-700 transition"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Episode Sebelumnya</span>
            </Link>
          ) : (
            <div className="opacity-40 pointer-events-none inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs sm:text-sm text-neutral-500">
              <ChevronLeft className="w-4 h-4" />
              <span>Episode Sebelumnya</span>
            </div>
          )}

          <Link
            href={`/detail/${data.animeSlug}`}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs text-neutral-400 hover:text-white transition"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Semua Episode</span>
          </Link>

          {data.nextEpisodeSlug ? (
            <Link
              href={`/watch/${data.nextEpisodeSlug}`}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-white text-black font-semibold text-xs sm:text-sm hover:bg-neutral-200 transition"
            >
              <span>Episode Selanjutnya</span>
              <ChevronRight className="w-4 h-4" />
            </Link>
          ) : (
            <div className="opacity-40 pointer-events-none inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-xs sm:text-sm text-neutral-500">
              <span>Episode Selanjutnya</span>
              <ChevronRight className="w-4 h-4" />
            </div>
          )}
        </div>

        {/* Quick Episode Switcher Grid */}
        <section className="rounded-xl border border-neutral-800 bg-[#141414] p-5">
          <div className="flex items-center justify-between pb-3 mb-4 border-b border-neutral-800">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Film className="w-4 h-4 text-neutral-400" />
              <span>Pilih Episode Lain ({fullEpisodes.length})</span>
            </h2>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2 max-h-64 overflow-y-auto pr-1">
            {fullEpisodes.map((ep) => {
              const isActive = ep.slug === data.episodeSlug;
              return (
                <Link
                  key={ep.slug}
                  href={`/watch/${ep.slug}`}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-lg text-xs font-semibold border transition ${
                    isActive
                      ? 'bg-white text-black border-white'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:bg-neutral-800 hover:text-white hover:border-neutral-700'
                  }`}
                >
                  <span className="text-[10px] text-neutral-400 font-normal">EP</span>
                  <span className="text-sm font-bold">{ep.number}</span>
                </Link>
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
}
