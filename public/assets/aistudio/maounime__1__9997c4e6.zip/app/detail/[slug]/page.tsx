import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ArrowLeft, Play, Star, Calendar, Film, Tv, Clock, Layers } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { getAnimeDetail } from '@/lib/sokuja';

interface PageProps {
  params: Promise<{ slug: string }>;
}

export const revalidate = 120; // 2 minutes ISR

export default async function AnimeDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const anime = await getAnimeDetail(slug);

  if (!anime) {
    notFound();
  }

  const latestEpisode = anime.episodes.length > 0 ? anime.episodes[0] : null;

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-neutral-100 flex flex-col">
      <Navbar />

      <main className="flex-1 pb-16">
        {/* Top Backdrop Header */}
        <div className="relative w-full h-64 sm:h-80 md:h-96 bg-neutral-900 overflow-hidden border-b border-neutral-800">
          <img
            src={anime.backdrop}
            alt={anime.title}
            className="w-full h-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-[#0a0a0a]/75" />

          {/* Back Navigation Bar */}
          <div className="absolute top-4 left-4 z-20">
            <Link
              href="/"
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/80 border border-neutral-800 text-xs font-medium text-neutral-300 hover:text-white hover:border-neutral-700 transition"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Kembali</span>
            </Link>
          </div>

          {/* Hero Content overlaid on Backdrop */}
          <div className="absolute inset-0 flex items-end p-4 sm:p-6 md:p-8 max-w-6xl mx-auto z-10">
            <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-end w-full">
              {/* Poster Box */}
              <div className="hidden sm:block w-36 md:w-44 shrink-0 aspect-[3/4] rounded-lg overflow-hidden border border-neutral-700 bg-neutral-900 shadow-xl">
                <img
                  src={anime.poster}
                  alt={anime.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Title & Key Badges */}
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2 mb-2 text-xs">
                  {anime.rating && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-neutral-900/90 border border-neutral-700 text-white font-semibold">
                      <Star className="w-3 h-3 text-neutral-300" />
                      {anime.rating}
                    </span>
                  )}
                  {anime.type && (
                    <span className="px-2.5 py-0.5 rounded bg-neutral-900/90 border border-neutral-700 text-neutral-300">
                      {anime.type}
                    </span>
                  )}
                  {anime.status && (
                    <span className="px-2.5 py-0.5 rounded bg-neutral-900/90 border border-neutral-700 text-neutral-300">
                      {anime.status}
                    </span>
                  )}
                  {anime.year && (
                    <span className="px-2.5 py-0.5 rounded bg-neutral-900/90 border border-neutral-700 text-neutral-300">
                      {anime.year}
                    </span>
                  )}
                </div>

                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-white mb-2">
                  {anime.title}
                </h1>

                {latestEpisode && (
                  <div className="mt-3">
                    <Link
                      href={`/watch/${latestEpisode.slug}`}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-white text-black font-semibold text-xs sm:text-sm hover:bg-neutral-200 transition"
                    >
                      <Play className="w-3.5 h-3.5 fill-black text-black" />
                      <span>Tonton {latestEpisode.title || `Episode ${latestEpisode.number}`}</span>
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Details & Episode List Container */}
        <div className="max-w-6xl mx-auto px-4 mt-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Column: Sinopsis and Metadata Information */}
          <div className="md:col-span-1 space-y-6">
            {/* Metadata Information Box */}
            <div className="rounded-xl border border-neutral-800 bg-[#141414] p-4 text-xs space-y-3">
              <h3 className="font-bold text-sm text-white uppercase tracking-wider pb-2 border-b border-neutral-800">
                Informasi
              </h3>

              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-500">Status</span>
                <span className="text-neutral-200 font-medium">{anime.status}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-500">Tipe</span>
                <span className="text-neutral-200 font-medium">{anime.type}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-500">Studio</span>
                <span className="text-neutral-200 font-medium">{anime.studio}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-500">Musim</span>
                <span className="text-neutral-200 font-medium">{anime.season}</span>
              </div>

              <div className="flex justify-between py-1 border-b border-neutral-800/60">
                <span className="text-neutral-500">Tahun</span>
                <span className="text-neutral-200 font-medium">{anime.year}</span>
              </div>

              {anime.director && (
                <div className="flex justify-between py-1 border-b border-neutral-800/60">
                  <span className="text-neutral-500">Sutradara</span>
                  <span className="text-neutral-200 font-medium">{anime.director}</span>
                </div>
              )}

              {anime.producer && (
                <div className="flex justify-between py-1 border-b border-neutral-800/60">
                  <span className="text-neutral-500">Produser</span>
                  <span className="text-neutral-200 font-medium">{anime.producer}</span>
                </div>
              )}

              <div className="flex justify-between py-1">
                <span className="text-neutral-500">Total Episode</span>
                <span className="text-neutral-200 font-medium">{anime.episodes.length} Episode</span>
              </div>
            </div>

            {/* Genres / Keywords */}
            {anime.genres.length > 0 && (
              <div className="rounded-xl border border-neutral-800 bg-[#141414] p-4 text-xs">
                <h3 className="font-bold text-sm text-white uppercase tracking-wider mb-3">
                  Genre
                </h3>
                <div className="flex flex-wrap gap-1.5">
                  {anime.genres.map((g) => (
                    <span
                      key={g}
                      className="px-2.5 py-1 rounded bg-neutral-900 border border-neutral-800 text-neutral-300 font-medium"
                    >
                      {g}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Sinopsis and Daftar Episode ke Bawah */}
          <div className="md:col-span-2 space-y-6">
            {/* Sinopsis */}
            <div className="rounded-xl border border-neutral-800 bg-[#141414] p-5">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3">
                Sinopsis
              </h2>
              <p className="text-sm text-neutral-300 leading-relaxed whitespace-pre-line">
                {anime.synopsis || 'Tidak ada deskripsi sinopsis.'}
              </p>
            </div>

            {/* Daftar Episode ke Bawah */}
            <div className="rounded-xl border border-neutral-800 bg-[#141414] p-5">
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-neutral-800">
                <h2 className="text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Layers className="w-4 h-4 text-neutral-400" />
                  <span>Daftar Episode ({anime.episodes.length})</span>
                </h2>
                <span className="text-xs text-neutral-500">
                  Pilih episode untuk menonton
                </span>
              </div>

              {anime.episodes.length === 0 ? (
                <p className="text-xs text-neutral-500 py-6 text-center">
                  Daftar episode belum tersedia atau sedang dalam pembaruan.
                </p>
              ) : (
                <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                  {anime.episodes.map((ep) => (
                    <Link
                      key={ep.slug}
                      href={`/watch/${ep.slug}`}
                      className="flex items-center justify-between p-3 rounded-lg border border-neutral-800/80 bg-neutral-900 hover:bg-neutral-800/80 hover:border-neutral-700 transition group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded bg-neutral-800 border border-neutral-700 flex items-center justify-center text-xs font-bold text-white group-hover:bg-white group-hover:text-black transition">
                          {ep.number}
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-medium text-neutral-200 group-hover:text-white transition">
                            {ep.title}
                          </h4>
                          {ep.date && (
                            <span className="text-[11px] text-neutral-500">
                              {ep.date}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 px-3 py-1 rounded bg-neutral-800 border border-neutral-700 text-xs font-medium text-neutral-300 group-hover:text-white transition">
                        <Play className="w-3 h-3 fill-current" />
                        <span>Tonton</span>
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
