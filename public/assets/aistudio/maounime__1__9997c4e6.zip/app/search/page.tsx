'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Search, ArrowLeft, Star, Film, Loader2 } from 'lucide-react';
import Navbar from '@/components/Navbar';

interface SearchResult {
  id?: number | string;
  slug: string;
  animeSlug?: string;
  title: string;
  cover: string;
  score?: string | number;
  type?: string;
  status?: string;
  year?: number | string;
}

const QUICK_SEARCH = [
  'Naruto',
  'Monster',
  'One Piece',
  'Bleach',
  'Black Clover',
  'Tokyo Revengers',
  'Isekai',
  'Action',
];

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  useEffect(() => {
    const timer = setTimeout(async () => {
      if (!query.trim()) {
        setResults([]);
        setSearched(false);
        return;
      }

      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        setResults(data.results || []);
        setSearched(true);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    }, query.trim() ? 400 : 0);

    return () => clearTimeout(timer);
  }, [query]);

  const handleQuickSelect = (tag: string) => {
    setQuery(tag);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-neutral-100 flex flex-col">
      <Navbar />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6">
        {/* Back button and page title */}
        <div className="flex items-center gap-3 mb-6">
          <Link
            href="/"
            className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700 transition"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-lg font-bold text-white tracking-tight">
            Pencarian Anime
          </h1>
        </div>

        {/* High-radius active Search Input */}
        <div className="relative w-full mb-5">
          <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-neutral-400" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ketik judul anime yang ingin dicari..."
            autoFocus
            className="w-full pl-12 pr-12 py-4 rounded-full bg-neutral-900 border border-neutral-800 text-sm md:text-base text-white placeholder-neutral-500 focus:outline-none focus:border-neutral-500 transition shadow-sm"
          />
          {loading && (
            <div className="absolute inset-y-0 right-0 pr-5 flex items-center">
              <Loader2 className="w-5 h-5 text-neutral-400 animate-spin" />
            </div>
          )}
        </div>

        {/* Quick Search Chips */}
        <div className="flex flex-wrap items-center gap-2 mb-8">
          <span className="text-xs text-neutral-500 font-medium mr-1">Rekomendasi:</span>
          {QUICK_SEARCH.map((tag) => (
            <button
              key={tag}
              onClick={() => handleQuickSelect(tag)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${
                query === tag
                  ? 'bg-white text-black border-white'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Search Results */}
        <section>
          {searched && (
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-neutral-800 text-xs text-neutral-400">
              <span>Hasil untuk: &ldquo;{query}&rdquo;</span>
              <span>Ditemukan {results.length} anime</span>
            </div>
          )}

          {loading && results.length === 0 && (
            <div className="text-center py-16 border border-neutral-800 rounded-xl bg-[#141414]">
              <Loader2 className="w-6 h-6 text-neutral-400 animate-spin mx-auto mb-2" />
              <p className="text-xs text-neutral-400">Mencari anime di database...</p>
            </div>
          )}

          {!loading && searched && results.length === 0 && (
            <div className="text-center py-16 border border-neutral-800 rounded-xl bg-[#141414]">
              <Film className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
              <p className="text-sm font-medium text-neutral-300">Tidak ada hasil ditemukan</p>
              <p className="text-xs text-neutral-500 mt-1">Coba gunakan kata kunci judul anime lainnya</p>
            </div>
          )}

          {results.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
              {results.map((item, idx) => (
                <Link
                  key={`${item.slug}-${idx}`}
                  href={`/detail/${item.slug}`}
                  className="group flex flex-col rounded-lg overflow-hidden bg-[#141414] border border-neutral-800 hover:border-neutral-600 transition"
                >
                  <div className="relative aspect-[3/4] w-full bg-neutral-900 overflow-hidden">
                    <img
                      src={item.cover}
                      alt={item.title}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />

                    {item.score && (
                      <div className="absolute top-2 right-2 flex items-center gap-0.5 px-2 py-0.5 rounded bg-black/85 border border-neutral-700/80 text-xs font-semibold text-neutral-200">
                        <Star className="w-3 h-3 text-neutral-300" />
                        <span>{item.score}</span>
                      </div>
                    )}

                    {item.type && (
                      <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-neutral-950/90 border border-neutral-800 text-[10px] font-semibold text-white">
                        {item.type}
                      </div>
                    )}
                  </div>

                  <div className="p-2.5 flex-1 flex flex-col justify-between">
                    <h3 className="text-xs sm:text-sm font-medium text-neutral-200 group-hover:text-white transition line-clamp-2">
                      {item.title}
                    </h3>
                    <div className="mt-2 flex items-center justify-between text-[11px] text-neutral-500">
                      <span>{item.status || 'Tersedia'}</span>
                      {item.year && <span>{item.year}</span>}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {!searched && !loading && (
            <div className="text-center py-16 border border-neutral-800/80 rounded-xl bg-neutral-900/30">
              <Search className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
              <p className="text-xs text-neutral-400">Silakan masukkan kata kunci judul anime di kolom pencarian di atas</p>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
