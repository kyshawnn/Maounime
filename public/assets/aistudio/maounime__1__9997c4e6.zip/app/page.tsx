import Link from 'next/link';
import { Search, Star, Play, Tv } from 'lucide-react';
import Navbar from '@/components/Navbar';
import { getHomeData } from '@/lib/sokuja';

export const revalidate = 120; // 2 minutes ISR

export default async function HomePage() {
  const { featured, latest } = await getHomeData();

  // If featured is available, use its data; fallback to first latest item
  const heroAnime = featured || (latest.length > 0 ? {
    slug: latest[0].animeSlug || latest[0].slug,
    title: latest[0].title,
    backdrop: latest[0].cover,
    rating: typeof latest[0].score === 'string' ? latest[0].score : '8.2',
    type: 'TV',
    studio: 'David Production',
    status: 'Ongoing',
    synopsis: 'Streaming dan download anime subtitle Indonesia terbaru kualitas HD.',
    genres: ['Action', 'Fantasy'],
    firstEpisodeSlug: latest[0].slug,
  } : null);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-neutral-100 flex flex-col">
      <Navbar />

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 pb-16">
        {/* Top Hero: Cover anime Backdrop, Judul di tengah, Rating, Type, Studio */}
        {heroAnime && (
          <section className="relative w-full rounded-2xl overflow-hidden mt-4 border border-neutral-800 bg-[#141414]">
            {/* Backdrop Image */}
            <div className="relative w-full h-72 sm:h-80 md:h-96 bg-neutral-900 overflow-hidden">
              <img
                src={heroAnime.backdrop}
                alt={heroAnime.title}
                className="w-full h-full object-cover opacity-35"
              />
              <div className="absolute inset-0 bg-[#0a0a0a]/60" />

              {/* Centered Content */}
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10 max-w-2xl mx-auto">
                {/* Meta info tags */}
                <div className="flex flex-wrap items-center justify-center gap-2 mb-3 text-xs">
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-neutral-200 font-semibold">
                    <Star className="w-3 h-3 text-neutral-300" />
                    {heroAnime.rating}
                  </span>
                  <span className="px-2.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-neutral-300">
                    {heroAnime.type}
                  </span>
                  <span className="px-2.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-neutral-300">
                    {heroAnime.studio}
                  </span>
                  <span className="px-2.5 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-neutral-300">
                    {heroAnime.status}
                  </span>
                </div>

                {/* Judul di tengah */}
                <h1 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-white mb-3 line-clamp-2">
                  {heroAnime.title}
                </h1>

                {/* Genres */}
                {heroAnime.genres && heroAnime.genres.length > 0 && (
                  <div className="flex flex-wrap items-center justify-center gap-1.5 mb-5 text-xs text-neutral-400">
                    {heroAnime.genres.slice(0, 4).map((g) => (
                      <span key={g} className="px-2 py-0.5 rounded bg-neutral-900/90 border border-neutral-800">
                        {g}
                      </span>
                    ))}
                  </div>
                )}

                {/* CTA Button */}
                <div className="flex items-center justify-center gap-3">
                  <Link
                    href={`/detail/${heroAnime.slug}`}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-white text-black font-semibold text-xs sm:text-sm hover:bg-neutral-200 transition"
                  >
                    <Play className="w-3.5 h-3.5 fill-black text-black" />
                    <span>Lihat Detail</span>
                  </Link>
                  {heroAnime.firstEpisodeSlug && (
                    <Link
                      href={`/watch/${heroAnime.firstEpisodeSlug}`}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-neutral-800 border border-neutral-700 text-white font-medium text-xs sm:text-sm hover:bg-neutral-700 transition"
                    >
                      <Tv className="w-3.5 h-3.5" />
                      <span>Tonton Langsung</span>
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Pencarian: Elemen beradius tinggi, bukan input, ketika dipencet navigasi ke halaman Pencarian */}
        <section className="mt-6 mb-8">
          <Link
            href="/search"
            className="w-full flex items-center justify-between rounded-full bg-neutral-900 border border-neutral-800 px-6 py-4 text-neutral-400 hover:text-white hover:border-neutral-600 transition shadow-sm group"
          >
            <div className="flex items-center gap-3">
              <Search className="w-4 h-4 text-neutral-400 group-hover:text-white transition" />
              <span className="text-xs sm:text-sm font-normal text-neutral-400 group-hover:text-neutral-200 transition">
                Cari judul anime, genre, atau episode...
              </span>
            </div>
            <span className="hidden sm:inline-block text-[11px] font-medium tracking-wide px-2.5 py-1 rounded-full bg-neutral-800 border border-neutral-700 text-neutral-400">
              Buka Pencarian
            </span>
          </Link>
        </section>

        {/* Anime Terbaru: 3x ke samping (grid-cols-3) */}
        <section>
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-neutral-800">
            <h2 className="text-base sm:text-lg font-bold tracking-tight text-white uppercase">
              Terbaru
            </h2>
            <span className="text-xs text-neutral-500 font-medium">
              Update Terkini
            </span>
          </div>

          {latest.length === 0 ? (
            <div className="text-center py-16 border border-neutral-800 rounded-xl bg-neutral-900/50">
              <p className="text-sm text-neutral-400">Sedang memuat data anime terbaru dari server...</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-2.5 sm:gap-4 md:gap-5">
              {latest.map((item, idx) => (
                <Link
                  key={`${item.slug}-${idx}`}
                  href={`/detail/${item.animeSlug || item.slug}`}
                  className="group flex flex-col rounded-lg overflow-hidden bg-[#141414] border border-neutral-800 hover:border-neutral-600 transition"
                >
                  {/* Card Cover with Skor di kanan atas & Eps di kiri bawah */}
                  <div className="relative aspect-[3/4] w-full bg-neutral-900 overflow-hidden">
                    <img
                      src={item.cover}
                      alt={item.title}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />

                    {/* Skor di kanan atas */}
                    {item.score && (
                      <div className="absolute top-1.5 right-1.5 sm:top-2 sm:right-2 z-10 flex items-center gap-0.5 px-1.5 sm:px-2 py-0.5 rounded bg-black/85 border border-neutral-700/80 text-[10px] sm:text-xs font-semibold text-neutral-200">
                        <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-neutral-300" />
                        <span>{item.score}</span>
                      </div>
                    )}

                    {/* Eps di kiri bawah */}
                    {item.episode && (
                      <div className="absolute bottom-1.5 left-1.5 sm:bottom-2 sm:left-2 z-10 px-1.5 sm:px-2 py-0.5 rounded bg-neutral-950/90 border border-neutral-800 text-[10px] sm:text-xs font-semibold text-white tracking-wide">
                        {item.episode}
                      </div>
                    )}
                  </div>

                  {/* Judul di bawah */}
                  <div className="p-2 sm:p-2.5 flex-1 flex flex-col justify-start">
                    <h3 className="text-xs sm:text-sm font-medium text-neutral-200 group-hover:text-white transition line-clamp-2 leading-snug">
                      {item.title}
                    </h3>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800 bg-[#0a0a0a] py-6 text-center text-xs text-neutral-500">
        <p>Maounime - Streaming Anime Subtitle Indonesia</p>
      </footer>
    </div>
  );
}
